// Pure helpers. No browser APIs in here so they can be tested on their own.

const SERVICES = {
  videos: {
    label: "AI product videos",
    short: "AI product videos",
    kw: /perfume|fragrance|oud|skincare|serum|cream|beauty|cosmetic|makeup|lotion|glow|scent/i,
    pain: (n) => `Most ${n || "beauty"} shoppers decide in the first few seconds of a product video, and flat photos rarely stop the scroll.`,
    offer: (n) => `I make AI product videos for ${n || "beauty"} stores that look like a studio shoot without the studio bill.`,
    ask: (c) => `Want me to send a short sample using ${c ? c + "'s" : "your"} product?`,
    subject: (c) => `Quick idea for ${c || "your"} product videos`,
  },
  ugc: {
    label: "AI UGC videos",
    short: "AI UGC videos",
    kw: /review|testimonial|unbox|haul|try on|tiktok shop|ugc|creator|affiliate/i,
    pain: () => "Customers trust other customers more than ads, but real UGC is slow and costly to collect.",
    offer: () => "I create AI UGC style videos that feel like real customer reviews, ready to post on TikTok and Reels.",
    ask: (c) => `Want a free sample clip for ${c || "your brand"}?`,
    subject: (c) => `UGC style videos for ${c || "your brand"}`,
  },
  website: {
    label: "Animated website",
    short: "an animated website",
    kw: /shop now|link in bio|store|shopify|order now|website|collection|new arrival|free shipping/i,
    pain: () => "A flat looking store loses visitors before they ever reach the product.",
    offer: (n) => `I build animated websites with cinematic product video heroes for ${n || "online"} brands.`,
    ask: (c) => `Want to see a quick mockup of how ${c ? c + "'s" : "your"} homepage could look?`,
    subject: (c) => `A new look for ${c || "your"} homepage`,
  },
  whatsapp: {
    label: "WhatsApp ads and direct booking",
    short: "WhatsApp ads and direct booking",
    kw: /book|appointment|dm to|whatsapp|consultation|reservation|clinic|salon|detailing|wedding|visa|travel/i,
    pain: () => "When a customer messages to book and nobody replies fast, they book somewhere else.",
    offer: () => "I set up WhatsApp ads and direct booking so enquiries turn into confirmed appointments automatically.",
    ask: (c) => `Can I show you how it would work for ${c || "your business"}?`,
    subject: (c) => `More bookings for ${c || "your business"} through WhatsApp`,
  },
  voice: {
    label: "AI voice receptionist",
    short: "an AI voice receptionist",
    kw: /call us|call now|hotline|emergency|24\/7|hvac|plumb|insurance|mortgage|real estate|realtor/i,
    pain: () => "Every missed call is a customer who rings your competitor next.",
    offer: () => "I build AI voice receptionists that answer calls, qualify the caller and book them in around the clock.",
    ask: () => "Would you be open to hearing a 2 minute demo?",
    subject: (c) => `Missed calls at ${c || "your business"}`,
  },
  automation: {
    label: "Workflow automation",
    short: "workflow automation",
    kw: /crm|leads|follow up|invoice|spreadsheet|agency|coach|consult|clients/i,
    pain: () => "Chasing leads and updating sheets by hand eats hours that should go into growth.",
    offer: () => "I automate follow ups, lead capture and reporting with n8n and the tools you already use.",
    ask: (c) => `Want me to point out the one task I would automate first for ${c || "your team"}?`,
    subject: (c) => `One task to automate at ${c || "your business"}`,
  },
};

const GENERIC = new Set(["info","hello","hi","hey","contact","support","sales","admin","enquiries","inquiries","enquiry","inquiry","orders","order","care","team","office","booking","bookings","press","mail","customerservice","customercare","shop","store","help","service","marketing","pr","media","partnerships","collabs","collab","wholesale","business","general","reception","studio"]);
const NOISE = /(sentry|wixpress|example\.com|schema\.org|w3\.org|your@|@2x|\.png|\.jpg|\.jpeg|\.gif|\.webp|\.svg|\.css|\.js$|u003e|noreply|no-reply|donotreply)/i;
const FREE = /^(gmail|yahoo|hotmail|outlook|icloud|proton|protonmail|live|aol|msn|ymail)\./i;

function tokens(name) {
  return (name || "").toLowerCase().replace(/[^a-z\s]/g, " ").split(/\s+/).filter((t) => t.length > 1);
}

function firstName(name) {
  const t = tokens(name)[0];
  return t ? t[0].toUpperCase() + t.slice(1) : "";
}

// Named = matches the person's name. Personal = looks like a person's own address. Business = public company address.
function classifyEmail(email, name) {
  const [local, domain = ""] = email.toLowerCase().split("@");
  const clean = local.replace(/[^a-z]/g, "");
  const toks = tokens(name);
  const generic = GENERIC.has(clean) || GENERIC.has(clean.replace(/s$/, ""));
  let named = false;
  if (toks.length) {
    const first = toks[0], last = toks[toks.length - 1];
    named = toks.some((t) => t.length > 2 && clean.includes(t)) || clean === first[0] + last;
  }
  if (named) return { type: "Named", rank: 0 };
  if (!generic) return { type: "Personal", rank: FREE.test(domain) ? 1 : 2 };
  return { type: "Business", rank: 3 };
}

function rankEmails(emails, name) {
  return [...new Set(emails)]
    .filter((e) => /^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(e) && !NOISE.test(e))
    .map((email) => ({ email, ...classifyEmail(email, name) }))
    .sort((a, b) => a.rank - b.rank);
}

function confidenceFor(type) {
  return type === "Named" ? "High" : type ? "Medium" : "Low";
}

function parseSocial(url, title) {
  let host = "", path = "";
  try { const u = new URL(url); host = u.hostname.replace(/^www\./, ""); path = u.pathname; } catch (e) {}
  const t = (title || "").trim().replace(/^\(\d+\)\s*/, "");
  let platform = "", handle = "", display = "";
  if (/(^|\.)instagram\.com$/.test(host)) {
    platform = "Instagram"; handle = path.split("/")[1] || "";
    display = t.split(" (@")[0].replace(/\s*[•|].*$/, "");
  } else if (/(^|\.)tiktok\.com$/.test(host)) {
    platform = "TikTok"; handle = (path.split("/")[1] || "").replace(/^@/, "");
    display = t.split(" (@")[0].replace(/\s*\|.*$/, "");
  } else if (/(^|\.)(facebook|fb)\.com$/.test(host)) {
    platform = "Facebook"; handle = path.split("/")[1] || "";
    display = t.split("|")[0].replace(/\s*[-–]\s*Home.*$/i, "");
  }
  return { platform, handle, display: display.trim() };
}

function suggestService(text) {
  const scores = Object.keys(SERVICES).map((k) => {
    const m = (text || "").match(new RegExp(SERVICES[k].kw.source, "gi"));
    return { k, n: m ? m.length : 0 };
  });
  scores.sort((a, b) => b.n - a.n);
  return scores[0].n > 0 ? scores[0].k : "videos";
}

function snippet(line, words = 9) {
  const s = (line || "")
    .replace(/https?:\/\/\S+/g, "")
    .replace(/[#@]\w+/g, "")
    .replace(/[\u{1F000}-\u{1FFFF}\u{2600}-\u{27BF}]/gu, "")
    .replace(/\s*[–—]\s*/g, " ")
    .replace(/\s-\s/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  const w = s.split(" ").filter(Boolean);
  if (w.length < 3) return "";
  return w.slice(0, words).join(" ") + (w.length > words ? "..." : "");
}

function buildHooks({ platform, lines = [], hashtags = [], bio = "", company = "" }) {
  const hooks = [];
  const p = platform || "social";
  lines.slice(0, 4).forEach((l) => {
    const s = snippet(l);
    if (s) hooks.push(`Saw your recent ${p} post: "${s}"`);
  });
  if (hashtags.length) {
    const tags = hashtags.slice(0, 2).join(" and ");
    hooks.push(`Noticed you post a lot around ${tags}`);
  }
  const f = (bio || "").match(/([\d.,]+\s?[KMkm]?)\s*Followers/);
  if (f) hooks.push(`Your ${p} page has built a real audience at ${f[1].trim()} followers`);
  if (company) hooks.push(`Came across ${company} on ${p} and liked the brand`);
  return hooks.slice(0, 6);
}

function withStop(s) {
  return /[.!?]$|[.!?]"$/.test(s) ? s : s + ".";
}

function buildMessage({ service, kind, channel, first, company, niche, hook, me, brand }) {
  const S = SERVICES[service] || SERVICES.videos;
  const hi = first ? `Hi ${first},` : "Hi,";
  const sign = [me, brand].filter(Boolean).join(", ");
  const h = hook ? withStop(hook) : "";
  if (kind === "follow") {
    const body = `Just following up on my note about ${S.short} for ${company || "your business"}. ${S.ask(company)} If the timing is wrong, no problem, just let me know.`;
    if (channel === "email") {
      return `Subject: Re: ${S.subject(company)}\n\n${hi}\n\n${body}\n\nBest,\n${sign}`;
    }
    return `${hi} ${body[0].toLowerCase()}${body.slice(1)}\n\n${sign}`;
  }
  const core = `${S.pain(niche)} ${S.offer(niche)}`;
  if (channel === "email") {
    return `Subject: ${S.subject(company)}\n\n${hi}\n\n${h ? h + "\n\n" : ""}${core}\n\n${S.ask(company)}\n\nBest,\n${sign}\n\nIf this is not relevant, reply "no" and I will not email again.`;
  }
  return `${hi} ${h ? h + " " : ""}${core} ${S.ask(company)}\n\n${sign}\nNot a fit? Tell me and I will not message again.`;
}

if (typeof module !== "undefined") {
  module.exports = { SERVICES, classifyEmail, rankEmails, confidenceFor, parseSocial, suggestService, buildHooks, buildMessage, firstName, snippet };
}
