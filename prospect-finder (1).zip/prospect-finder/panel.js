const $ = (id) => document.getElementById(id);
const state = { emails: [], sources: [], hooks: [], links: [], platform: "", handle: "" };
const FIELDS = ["niche", "region", "f_name", "f_role", "f_company", "f_niche", "f_website", "f_email", "f_source", "f_conf", "f_hook", "f_service", "f_kind", "f_channel", "f_msg", "s_me", "s_brand"];

// ---------- setup ----------
Object.keys(SERVICES).forEach((k) => {
  const o = document.createElement("option");
  o.value = k;
  o.textContent = SERVICES[k].label;
  $("f_service").append(o);
});

document.querySelectorAll(".tab").forEach((t) =>
  t.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach((x) => x.classList.toggle("active", x === t));
    document.querySelectorAll(".panel").forEach((p) => p.classList.toggle("active", p.id === t.dataset.tab));
    if (t.dataset.tab === "list") renderList();
  })
);

async function getAll() {
  return (await chrome.storage.local.get("prospects")).prospects || [];
}
async function setAll(list) {
  await chrome.storage.local.set({ prospects: list });
  $("count").textContent = list.length;
}

function persist() {
  const d = { state, auto: $("f_email").dataset.auto || "", edited: $("f_msg").dataset.edited || "", touched: $("f_service").dataset.touched || "" };
  FIELDS.forEach((id) => (d[id] = $(id).value));
  chrome.storage.local.set({ draft: d });
}

async function restore() {
  const { draft } = await chrome.storage.local.get("draft");
  if (!draft) return;
  FIELDS.forEach((id) => { if (draft[id] !== undefined) $(id).value = draft[id]; });
  Object.assign(state, draft.state || {});
  $("f_email").dataset.auto = draft.auto || "";
  $("f_msg").dataset.edited = draft.edited || "";
  $("f_service").dataset.touched = draft.touched || "";
  renderEmails(); renderHooks(); renderLinks();
}

function say(id, text, err) {
  const m = $(id);
  m.className = "msg" + (err ? " err" : "");
  m.textContent = text;
}

// ---------- find tab ----------
function showQueries(target, queries) {
  const box = $(target);
  box.innerHTML = "";
  queries.forEach(({ label, q }) => {
    const row = document.createElement("div");
    row.className = "q";
    const code = document.createElement("code");
    code.textContent = q;
    code.title = label;
    const open = document.createElement("button");
    open.textContent = "Search";
    open.onclick = () => chrome.tabs.create({ url: "https://www.google.com/search?q=" + encodeURIComponent(q) });
    const copy = document.createElement("button");
    copy.textContent = "Copy";
    copy.onclick = async () => {
      await navigator.clipboard.writeText(q);
      copy.textContent = "Copied";
      setTimeout(() => (copy.textContent = "Copy"), 1200);
    };
    row.append(code, open, copy);
    box.append(row);
  });
}

$("build").onclick = () => {
  const n = $("niche").value.trim();
  if (!n) return;
  if (!$("f_niche").value) $("f_niche").value = n;
  const r = $("region").value.trim();
  const loc = r ? ` "${r}"` : "";
  const roles = '(founder OR owner OR CEO OR "brand director")';
  showQueries("queries", [
    { label: "Owners and founders", q: `"${n}" AND ${roles}${loc}` },
    { label: "Brand owners", q: `("${n} founder" OR "${n} brand owner")${loc}` },
    { label: "LinkedIn owners", q: `site:linkedin.com/in (Founder OR Owner OR CEO) "${n}"${loc}` },
    { label: "LinkedIn marketing leads", q: `site:linkedin.com/in ("brand director" OR "head of marketing" OR "marketing manager") "${n}"${loc}` },
    { label: "Instagram brands", q: `site:instagram.com "${n}" (founder OR owner OR "shop now")${loc}` },
    { label: "TikTok brands", q: `site:tiktok.com "${n}" (founder OR owner OR "shop now")${loc}` },
    { label: "Facebook pages", q: `site:facebook.com "${n}" (founder OR owner OR "message us")${loc}` },
    { label: "Interviews and press", q: `"${n}" (founder OR owner) (interview OR "press release" OR featured)${loc}` },
  ]);
  persist();
};

$("buildPerson").onclick = () => {
  const name = $("pname").value.trim();
  const domain = $("pdomain").value.trim().replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/\/.*$/, "");
  if (!name || !domain) return;
  const n = $("niche").value.trim();
  showQueries("personQueries", [
    { label: "Email on the web", q: `"${name}" "@${domain}"` },
    { label: "On the company site", q: `site:${domain} "${name}" (email OR contact)` },
    { label: "Contact or team page", q: `site:${domain} (contact OR "about us" OR team)` },
    { label: "Their social pages", q: `"${name}" (instagram OR tiktok OR facebook)${n ? ` "${n}"` : ""}` },
    { label: "Email in a bio", q: `"${name}" "${domain.split(".")[0]}" "@gmail.com" OR "email me"` },
  ]);
};

// ---------- reading a page ----------
function readPage() {
  const text = (document.body ? document.body.innerText : "").slice(0, 200000);
  const metaOf = (n) => {
    const el = document.querySelector(`meta[property="${n}"],meta[name="${n}"]`);
    return el ? el.content || "" : "";
  };
  const found = new Set();
  document.querySelectorAll('a[href^="mailto:"]').forEach((a) => {
    try {
      const e = decodeURIComponent(a.getAttribute("href").replace(/^mailto:/i, "").split("?")[0]).trim();
      if (e) found.add(e.toLowerCase());
    } catch (err) {}
  });
  const re = /[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/gi;
  [text, metaOf("og:description"), metaOf("description"), document.title].forEach((s) =>
    (s.match(re) || []).forEach((e) => found.add(e.toLowerCase()))
  );

  const ui = /(log in|sign up|privacy|terms of|cookie|see more|get the app|download the app|create new|forgot password|©|all rights reserved)/i;
  const stat = /\b\d[\d.,KMkm]*\s*(followers|following|likes|posts|views)\b/i;
  const seen = new Set();
  const lines = [];
  for (const raw of text.split("\n")) {
    const l = raw.trim();
    if (l.length < 30 || l.length > 260 || ui.test(l) || stat.test(l)) continue;
    const k = l.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    lines.push(l);
    if (lines.length >= 8) break;
  }

  const freq = {};
  (text.match(/#[A-Za-z][A-Za-z0-9_]{2,30}/g) || []).forEach((h) => {
    const k = h.toLowerCase();
    freq[k] = (freq[k] || 0) + 1;
  });
  const hashtags = Object.keys(freq).sort((a, b) => freq[b] - freq[a]).slice(0, 5);

  const onSocial = /(instagram|tiktok|facebook|fb)\.com$/.test(location.hostname);
  const links = new Set();
  if (onSocial) {
    const skip = /(instagram|facebook|tiktok|fb\.com|meta\.com|whatsapp|google|apple\.com|youtube|twitter|x\.com|threads\.net|linkedin)/i;
    document.querySelectorAll("a[href]").forEach((a) => {
      try {
        let u = new URL(a.href);
        if (/^l\.(instagram|facebook)\.com$/.test(u.hostname) && u.searchParams.get("u")) u = new URL(u.searchParams.get("u"));
        if (u.protocol.startsWith("http") && u.hostname !== location.hostname && !skip.test(u.hostname)) {
          links.add(u.origin + u.pathname.replace(/\/$/, ""));
        }
      } catch (err) {}
    });
  }

  return {
    title: document.title,
    ogTitle: metaOf("og:title"),
    bio: metaOf("og:description") || metaOf("description"),
    url: location.href,
    host: location.hostname.replace(/^www\./, ""),
    site: metaOf("og:site_name"),
    emails: [...found],
    lines, hashtags,
    links: [...links].slice(0, 4),
    selection: String(getSelection()).trim().slice(0, 120),
  };
}

// ---------- rendering ----------
function renderEmails() {
  const ranked = rankEmails(state.emails, $("f_name").value);
  const box = $("emailChips");
  box.innerHTML = "";
  ranked.forEach((r) => {
    const c = document.createElement("span");
    c.className = "chip " + r.type;
    c.textContent = `${r.email} (${r.type})`;
    c.onclick = () => {
      $("f_email").value = r.email;
      $("f_email").dataset.auto = "";
      $("f_conf").value = confidenceFor(r.type);
      persist();
    };
    box.append(c);
  });
  const fe = $("f_email");
  const free = !fe.value || fe.value === fe.dataset.auto;
  if (free) {
    const best = ranked[0];
    fe.value = best ? best.email : "";
    fe.dataset.auto = fe.value;
    $("f_conf").value = confidenceFor(best && best.type);
  }
  return ranked;
}

function renderHooks() {
  const box = $("hookChips");
  box.innerHTML = "";
  state.hooks.forEach((h) => {
    const c = document.createElement("span");
    c.className = "chip hook";
    c.textContent = h;
    c.onclick = () => { $("f_hook").value = h; refreshMsg(true); };
    box.append(c);
  });
}

function renderLinks() {
  const box = $("linkChips");
  box.innerHTML = "";
  state.links.forEach((l) => {
    const c = document.createElement("span");
    c.className = "chip link";
    c.textContent = l;
    c.onclick = () => { $("f_website").value = l; persist(); };
    box.append(c);
  });
}

function refreshMsg(force) {
  const msg = $("f_msg");
  if (!force && msg.dataset.edited) return;
  msg.value = buildMessage({
    service: $("f_service").value,
    kind: $("f_kind").value,
    channel: $("f_channel").value,
    first: firstName($("f_name").value),
    company: $("f_company").value.trim(),
    niche: ($("f_niche").value || $("niche").value).trim(),
    hook: $("f_hook").value.trim(),
    me: $("s_me").value.trim(),
    brand: $("s_brand").value.trim(),
  });
  if (force) msg.dataset.edited = "";
  persist();
}

// ---------- capture ----------
$("read").onclick = async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  try {
    const [{ result: r }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: readPage });
    const soc = parseSocial(r.url, r.ogTitle || r.title);

    if (r.selection) $("f_name").value = r.selection;

    if (soc.platform) {
      state.platform = soc.platform;
      state.handle = soc.handle;
      if (!$("f_company").value) $("f_company").value = soc.display;
      state.hooks = buildHooks({ platform: soc.platform, lines: r.lines, hashtags: r.hashtags, bio: r.bio, company: soc.display });
      if (!$("f_hook").value && state.hooks[0]) $("f_hook").value = state.hooks[0];
      if (r.links.length) {
        state.links = r.links;
        if (!$("f_website").value) $("f_website").value = r.links[0];
      }
    } else if (/linkedin\.com/.test(r.host)) {
      const parts = r.title.replace(/\s*\|\s*LinkedIn.*$/i, "").split(" - ");
      if (parts[0] && !$("f_name").value) $("f_name").value = parts[0].trim();
      if (parts[1] && !$("f_role").value) $("f_role").value = parts[1].trim();
      if (parts[2] && !$("f_company").value) $("f_company").value = parts[2].trim();
    } else {
      if (!$("f_company").value) $("f_company").value = r.site || r.host.split(".")[0];
      if (!$("f_website").value) $("f_website").value = "https://" + r.host;
    }

    state.emails = [...new Set([...state.emails, ...r.emails])];
    if (!state.sources.includes(r.url)) state.sources.push(r.url);
    $("f_source").value = state.sources.join(" | ");

    if (!$("f_service").dataset.touched) {
      $("f_service").value = suggestService([r.bio, r.lines.join(" "), r.hashtags.join(" "), $("f_company").value].join(" "));
    }

    const ranked = renderEmails();
    renderHooks();
    renderLinks();
    refreshMsg(false);

    const best = ranked[0];
    say("msg", best
      ? `${ranked.length} email${ranked.length > 1 ? "s" : ""} found so far. Best pick: ${best.email} (${best.type}).`
      : "No email shown on this page yet. Open their website or contact page and read it too.");
  } catch (err) {
    say("msg", "Could not read this page. Browser internal pages are blocked.", true);
  }
  persist();
};

$("fresh").onclick = () => {
  ["f_name", "f_role", "f_company", "f_website", "f_email", "f_source", "f_hook", "f_msg"].forEach((id) => ($(id).value = ""));
  $("f_email").dataset.auto = "";
  $("f_msg").dataset.edited = "";
  $("f_service").dataset.touched = "";
  $("f_conf").value = "Low";
  Object.assign(state, { emails: [], sources: [], hooks: [], links: [], platform: "", handle: "" });
  renderEmails(); renderHooks(); renderLinks();
  say("msg", "Cleared. Ready for the next prospect.");
  persist();
};

$("openSite").onclick = () => {
  const u = $("f_website").value.trim();
  if (u) chrome.tabs.create({ url: /^https?:\/\//.test(u) ? u : "https://" + u });
};

["f_service", "f_kind", "f_channel"].forEach((id) =>
  $(id).addEventListener("change", () => {
    if (id === "f_service") $("f_service").dataset.touched = "1";
    refreshMsg(false);
  })
);
["f_hook", "f_company", "f_niche", "s_me", "s_brand"].forEach((id) => $(id).addEventListener("input", () => refreshMsg(false)));
$("f_name").addEventListener("input", () => { renderEmails(); refreshMsg(false); });
$("f_msg").addEventListener("input", () => { $("f_msg").dataset.edited = "1"; persist(); });
["f_role", "f_website", "f_email", "f_source", "f_conf", "niche", "region"].forEach((id) => $(id).addEventListener("input", persist));
$("rewrite").onclick = () => refreshMsg(true);
$("copyMsg").onclick = async () => {
  await navigator.clipboard.writeText($("f_msg").value);
  say("msg2", "Message copied.");
};

$("save").onclick = async () => {
  const ranked = rankEmails([$("f_email").value.trim()].filter(Boolean), $("f_name").value);
  const p = {
    id: Date.now(),
    name: $("f_name").value.trim(),
    role: $("f_role").value.trim(),
    company: $("f_company").value.trim(),
    email: $("f_email").value.trim(),
    emailType: ranked[0] ? ranked[0].type : "",
    platform: state.platform,
    handle: state.handle,
    website: $("f_website").value.trim(),
    service: SERVICES[$("f_service").value].label,
    hook: $("f_hook").value.trim(),
    message: $("f_msg").value,
    confidence: $("f_conf").value,
    status: "Not contacted",
    source: $("f_source").value.trim(),
    saved: new Date().toISOString().slice(0, 10),
  };
  if (!p.name && !p.company) return say("msg2", "Add at least a name or a company.", true);
  const list = await getAll();
  if (p.email && list.some((x) => x.email.toLowerCase() === p.email.toLowerCase())) return say("msg2", "That email is already in your list.", true);
  list.unshift(p);
  await setAll(list);
  say("msg2", "Saved to list.");
};

// ---------- list ----------
async function renderList() {
  const list = await getAll();
  const q = $("filter").value.toLowerCase();
  const box = $("rows");
  box.innerHTML = "";
  const shown = list.filter((p) => [p.name, p.company, p.role, p.email, p.platform, p.service].join(" ").toLowerCase().includes(q));
  if (!shown.length) {
    box.innerHTML = '<p class="hint">Nothing here yet. Read a page in Capture and save a prospect.</p>';
    return;
  }
  shown.forEach((p) => {
    const d = document.createElement("div");
    d.className = "p";
    const b = document.createElement("b");
    b.textContent = p.name || p.company;
    const tag = document.createElement("span");
    tag.className = "tag " + p.confidence;
    tag.textContent = p.confidence;
    b.append(" ", tag);
    const m = document.createElement("div");
    m.className = "meta";
    m.textContent = [p.role, p.name ? p.company : "", p.platform && `${p.platform} ${p.handle || ""}`.trim(), p.email && `${p.email} (${p.emailType || "email"})`, p.service, p.status].filter(Boolean).join(", ");
    const a = document.createElement("div");
    a.className = "acts";
    const mk = (label, fn) => { const x = document.createElement("button"); x.textContent = label; x.onclick = fn; return x; };
    a.append(
      mk(p.status === "Contacted" ? "Mark not contacted" : "Mark contacted", async () => {
        const all = await getAll();
        const it = all.find((x) => x.id === p.id);
        it.status = it.status === "Contacted" ? "Not contacted" : "Contacted";
        await setAll(all);
        renderList();
      }),
      mk("Copy message", () => navigator.clipboard.writeText(p.message || "")),
      mk("Source", () => p.source && chrome.tabs.create({ url: p.source.split(" | ")[0] })),
      mk("Delete", async () => { await setAll((await getAll()).filter((x) => x.id !== p.id)); renderList(); })
    );
    d.append(b, m, a);
    box.append(d);
  });
}
$("filter").addEventListener("input", renderList);

$("export").onclick = async () => {
  const list = await getAll();
  const cols = ["name", "role", "company", "email", "emailType", "platform", "handle", "website", "service", "hook", "message", "confidence", "status", "source", "saved"];
  const esc = (v) => '"' + String(v ?? "").replace(/"/g, '""') + '"';
  const csv = [cols.join(","), ...list.map((p) => cols.map((c) => esc(p[c])).join(","))].join("\n");
  const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = "prospects.csv";
  a.click();
  URL.revokeObjectURL(url);
};

$("clear").onclick = async () => {
  if (confirm("Delete every saved prospect? This cannot be undone.")) {
    await setAll([]);
    renderList();
  }
};

getAll().then((l) => ($("count").textContent = l.length));
restore().then(() => { if (!$("f_msg").value) refreshMsg(true); });
